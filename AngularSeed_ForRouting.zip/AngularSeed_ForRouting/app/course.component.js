"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var likes_component_1 = require('./likes.component');
var highlightedcourse_directive_1 = require('./highlightedcourse.directive');
var summary_pipe_1 = require('./summary.pipe');
var CourseComponent = (function () {
    function CourseComponent() {
        this.actualCourse = {};
    }
    //thecurrentDateAndTime = new Observable<string>((observer: Subscriber<string>) => {
    //    setInterval(() => observer.next(new Date().toString()), 5000);
    //})
    CourseComponent.prototype.ChangeLikesHandler = function ($event) {
        //console.log($event);
        this.actualCourse.likes = $event; // from likes component !
    };
    __decorate([
        core_1.Input('courseOffered'), 
        __metadata('design:type', Object)
    ], CourseComponent.prototype, "actualCourse", void 0);
    CourseComponent = __decorate([
        core_1.Component({
            selector: 'course',
            templateUrl: '/app/course.component.html',
            inputs: ['courseOffered'],
            directives: [likes_component_1.LikeComponent, highlightedcourse_directive_1.HighlightCourse],
            pipes: [summary_pipe_1.SummaryPipe]
        }), 
        __metadata('design:paramtypes', [])
    ], CourseComponent);
    return CourseComponent;
}());
exports.CourseComponent = CourseComponent;
//import {Component} from '@angular/core';
//import {CourseDataService, CourseDataService2} from './course.service';
//@Component({
//    selector: 'course',
//    template: `
//                    <div id="container">
//                    <h1> Course 1 </h1>
//                    <button (click)="onGetCourse()">Get Random Course </button>
//                    <p>  Course Name : {{ actualCourse }}  </p>
//                    <p> Another Course : {{anotherCourse}} </p>
//                    <input type="text" #input />
//                    <button (click)="onAddCourse(input.value)" > Add New Course </button>
//                           <input type="text" #anotherinput />                    
//                        <button (click)="onAnotherCourseAdd(anotherinput.value)">Add another course </button>
//                        <div>
//                    `,
//    providers: [CourseDataService2],
//    styles: [
//        `#container{
//                border:2px solid red;
//                border-radius:10px;
//                padding:10px;
//        }   
//        `
//    ]
//})
//export class CourseComponent {
//    actualCourse: string = '';
//    anotherCourse: string = '';
//    // DI
//    constructor(private dataServiceObj: CourseDataService, private dataCourse2Obj: CourseDataService2) {
//        this.actualCourse = this.dataServiceObj.getRandomCourse();
//    }
//    onGetCourse() {
//        this.actualCourse = this.dataServiceObj.getRandomCourse();
//        this.anotherCourse = this.dataCourse2Obj.getRandomCourse();
//    }
//    onAddCourse(newCourse) {
//       this.dataServiceObj.insertNewCourse(newCourse);       
//    }
//    onAnotherCourseAdd(newCourse) {
//        this.dataCourse2Obj.insertNewCourse(newCourse);
//    }
//} 
//# sourceMappingURL=course.component.js.map