import {Component} from '@angular/core';
import {CourseComponent} from './course.component';


@Component({
    selector: 'my-app',
//    template: `<h1> Hello {{ courseName  }}  ! </h1>

//            <div  *ngIf="!isDisabled">

//                        <img src="{{ imageUrl }}" height="100px" width="200px" />
//                        <img [src]="imageUrl"  height="100px" width="200px" />
//                        <img bind-src="imageUrl"  height="100px" width="200px" />
//                        <input type="button" class="btn" [class.btn-success]="!isSuccess"  value="Class applied !" />
//                    <input type="button" [style.backgroundColor]="isSuccess ? 'green' : 'orange'"   value="Styled button !" />
//                    <input type="button" class="btn btn-success"  value="Click me !" (click)="HandleClick()" />
//                    <input type="button" value="Using ngClass Directive !" [ngClass]="{
                                        
//                                        'btn':isDisabled,
//                                        'btn-success':!isSuccess
                                        
//                                }"  />

//</div>


// `,
    //template: `<h1> Hello {{ courseName  }}  ! </h1>
    //                    <course></course>
    //                    <input type="button" [disabled]=isDisabled value="Disabled ?" />
    //                `,

    //templateUrl: '/app/app.component.html',
    //template: `
    //                    <ul>
    //                            <li *ngFor="let c of courses">
    //                                    {{ c }}
    //                            </li>
    //                    </ul>
                    
    //            `,

    template: `<h1> Hello {{ courseName  }}  ! </h1>
                              Enter CourseName here : <input type="text" [value]="courseName" (input)="HandleChange($event)" /><br/>
                             <input type="text" [(ngModel)]="courseName" /> <br/>
                                Is Success ?? : <input type="checkbox" [(ngModel)]="isSuccess" />
                                <input type="button" class="btn" [class.btn-success]="isSuccess"  value="Click me !" (click)="HandleClick()" />

                    `
})
export class AppComponent {
    //model
    courseName: string = "Angular 2";   
    imageUrl: string = "http://blog.ninja-squad.com/assets/images/ng2-ebook/ng2-logo.png";
    isDisabled: boolean = true;
    isSuccess = false;
    courses: string[] = ['ReactJS','AngularJS','PolymerJS'];

    HandleClick() {
       // console.log('U Clicked !');
        this.courseName = "ReactJS";
    }

    HandleChange($event) {
        // target -> object on which event has fired ! (textbox)
        this.courseName = $event.target.value;
        //console.log($event);
    }
}