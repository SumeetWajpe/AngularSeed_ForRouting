import {bootstrap}    from '@angular/platform-browser-dynamic'
import {AppComponent} from './app.component';
import {MainComponent} from './main.component';

import {CourseDataService} from './course.service';
import {HTTP_PROVIDERS} from '@angular/http';
import {ROUTER_PROVIDERS} from '@angular/router-deprecated';


bootstrap(MainComponent, [CourseDataService, HTTP_PROVIDERS, ROUTER_PROVIDERS]);



