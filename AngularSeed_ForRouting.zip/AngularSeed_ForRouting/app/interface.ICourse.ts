﻿ interface ICourse {
    title: string;
    duration: string;
    rating: number;
    price: number;
}

export default ICourse;