﻿//import {Directive, Input,ElementRef} from '@angular/core';

//@Directive({   
//    //selector: '.courseHighlight'
//    selector: '[courseHighlight]'
//})
//export class HighlightCourse {
//    constructor(element: ElementRef) {
//        element.nativeElement.style.backgroundColor = 'lightgreen';
//    }
//}
/*/////////////////////////// Use directives with some event condition */

import {Directive, Input, ElementRef,HostListener} from '@angular/core';

@Directive({
    //selector: '.courseHighlight'
    selector: '[courseHighlight]',
    inputs: ['coursecolor']
})
export class HighlightCourse {

    @Input('coursecolor') passedcolor: string = "";

    constructor(private element: ElementRef) {
    }
    @HostListener('mouseenter') onMouseEnter() {
        this.highlight(this.passedcolor);
    }

    @HostListener('mouseleave') onMouseLeave() {
        this.highlight(null);
    }

    private highlight(color: string) {
       this.element.nativeElement.style.backgroundColor =color;
    }
}
