﻿import {Component, Input} from '@angular/core';
import {LikeComponent} from './likes.component';
import {HighlightCourse} from './highlightedcourse.directive';

import {SummaryPipe} from './summary.pipe';
import {Observable} from 'rxjs/Observable';


@Component({
    selector: 'course',
    templateUrl: '/app/course.component.html',
    inputs: ['courseOffered'],
    directives: [LikeComponent, HighlightCourse],
    pipes: [SummaryPipe]
})
export class CourseComponent {
    @Input('courseOffered') actualCourse: any = {};
    //thecurrentDateAndTime = new Observable<string>((observer: Subscriber<string>) => {
    //    setInterval(() => observer.next(new Date().toString()), 5000);
    //})
    ChangeLikesHandler($event) {
        //console.log($event);
        this.actualCourse.likes = $event;// from likes component !
    }
}


//import {Component} from '@angular/core';
//import {CourseDataService, CourseDataService2} from './course.service';


//@Component({
//    selector: 'course',
//    template: `
//                    <div id="container">
//                    <h1> Course 1 </h1>
//                    <button (click)="onGetCourse()">Get Random Course </button>
//                    <p>  Course Name : {{ actualCourse }}  </p>
//                    <p> Another Course : {{anotherCourse}} </p>
//                    <input type="text" #input />
//                    <button (click)="onAddCourse(input.value)" > Add New Course </button>
//                           <input type="text" #anotherinput />                    
//                        <button (click)="onAnotherCourseAdd(anotherinput.value)">Add another course </button>

//                        <div>
//                    `,
//    providers: [CourseDataService2],
//    styles: [
//        `#container{
//                border:2px solid red;
//                border-radius:10px;
//                padding:10px;
//        }   
//        `
//    ]
//})
//export class CourseComponent {
//    actualCourse: string = '';
//    anotherCourse: string = '';
//    // DI
//    constructor(private dataServiceObj: CourseDataService, private dataCourse2Obj: CourseDataService2) {
//        this.actualCourse = this.dataServiceObj.getRandomCourse();
//    }

//    onGetCourse() {
//        this.actualCourse = this.dataServiceObj.getRandomCourse();
//        this.anotherCourse = this.dataCourse2Obj.getRandomCourse();

//    }

//    onAddCourse(newCourse) {
//       this.dataServiceObj.insertNewCourse(newCourse);       
//    }
//    onAnotherCourseAdd(newCourse) {
//        this.dataCourse2Obj.insertNewCourse(newCourse);

//    }



//}