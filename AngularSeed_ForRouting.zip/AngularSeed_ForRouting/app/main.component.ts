﻿import {Component} from '@angular/core';
import {ContactComponent} from './contact.component';
import {AppComponent} from './app.component';
import {RouteConfig,RouterOutlet,RouterLink} from '@angular/router-deprecated';


@RouteConfig([
    { path: '/courses', name: 'Courses', component: AppComponent },
    { path: '/contact', name: 'Contact', component: ContactComponent },
    { path: '/*other', name: 'others', redirectTo: ['Courses'] }

])

@Component({
    selector: 'Main',
    templateUrl: '/app/main.component.html',
    directives: [RouterOutlet, RouterLink]
})
export class MainComponent {
}