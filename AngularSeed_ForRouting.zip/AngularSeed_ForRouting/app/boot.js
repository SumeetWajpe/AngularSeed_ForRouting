"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var main_component_1 = require('./main.component');
var course_service_1 = require('./course.service');
var http_1 = require('@angular/http');
var router_deprecated_1 = require('@angular/router-deprecated');
platform_browser_dynamic_1.bootstrap(main_component_1.MainComponent, [course_service_1.CourseDataService, http_1.HTTP_PROVIDERS, router_deprecated_1.ROUTER_PROVIDERS]);
//# sourceMappingURL=boot.js.map