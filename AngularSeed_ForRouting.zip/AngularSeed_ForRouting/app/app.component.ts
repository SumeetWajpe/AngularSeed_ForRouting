import {Component} from '@angular/core';
import {CourseComponent} from './course.component';


@Component({
    selector: 'my-app',
    //template: `
    //                    <course></course>
    //                    <hr/>
    //                    <course></course>
    //                `,
    templateUrl:'/app/app.component.html',
    directives: [CourseComponent]
})
export class AppComponent {
    //model
    searchForCourse: string = "";
    courses: any[];


    ngOnInit() {
        
        this.courses = [
            {
                title: 'AngularJS', duration: '3 Days', rating: 4.5, price: 20000, likes: 20, date: new Date(), description: `NEW DELHI: Ravindra Jadeja has been rewarded for his all-round show in the ongoing home season as BCCI elevated him to Grade A in the annual contracts for the 2017-18 season announced on Wednesday. Along with Jadeja, Cheteshwar Pujara and Murali Vijay also jumped to the top category.
The Committee of Administrators (COA) met earlier in the day to decide on the annual player contracts for men cricketers for the period ending 30 September 2017.` },
            {
                title: 'ReactJS', duration: '5 Days', rating: 4, price: 90000, likes: 50, date: new Date(), description: `NEW DELHI: Ravindra Jadeja has been rewarded for his all-round show in the ongoing home season as BCCI elevated him to Grade A in the annual contracts for the 2017-18 season announced on Wednesday. Along with Jadeja, Cheteshwar Pujara and Murali Vijay also jumped to the top category.
The Committee of Administrators (COA) met earlier in the day to decide on the annual player contracts for men cricketers for the period ending 30 September 2017.` },
            {
                title: 'PolymerJS', duration: '2 Days', rating: 4.56788, price: 40000, likes: 60, date: new Date(), description: `NEW DELHI: Ravindra Jadeja has been rewarded for his all-round show in the ongoing home season as BCCI elevated him to Grade A in the annual contracts for the 2017-18 season announced on Wednesday. Along with Jadeja, Cheteshwar Pujara and Murali Vijay also jumped to the top category.
The Committee of Administrators (COA) met earlier in the day to decide on the annual player contracts for men cricketers for the period ending 30 September 2017.`  },
            {
                title: 'BackboneJS', duration: '4 Days', rating: 4.5, price: 80000, likes: 70, date: new Date(), description: `NEW DELHI: Ravindra Jadeja has been rewarded for his all-round show in the ongoing home season as BCCI elevated him to Grade A in the annual contracts for the 2017-18 season announced on Wednesday. Along with Jadeja, Cheteshwar Pujara and Murali Vijay also jumped to the top category.
The Committee of Administrators (COA) met earlier in the day to decide on the annual player contracts for men cricketers for the period ending 30 September 2017.`  }
        ];
    }

    onSubmitForm(form) {

        let newCourse = {
            title: form.controls.title.value,
            price: form.controls.price.value,
            duration: form.controls.duration.value,
            rating: form.controls.rating.value
        }      
        this.courses.push(newCourse);
    }

   
}

