"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var http_1 = require('@angular/http');
var core_1 = require('@angular/core');
var CourseDataService = (function () {
    function CourseDataService(_http) {
        this._http = _http;
        this.courses = ['ReactJS', 'Angular2', 'NodeJS']; // get the data from server !
    }
    CourseDataService.prototype.getRandomCourse = function () {
        return this.courses[Math.floor(Math.random() * this.courses.length)];
    };
    CourseDataService.prototype.insertNewCourse = function (newCourse) {
        this.courses.push(newCourse);
    };
    CourseDataService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], CourseDataService);
    return CourseDataService;
}());
exports.CourseDataService = CourseDataService;
var CourseDataService2 = (function () {
    function CourseDataService2() {
        this.courses = ['.NET', 'Java', 'PHP']; // get the data from server !
    }
    CourseDataService2.prototype.getRandomCourse = function () {
        return this.courses[Math.floor(Math.random() * this.courses.length)];
    };
    CourseDataService2.prototype.insertNewCourse = function (newCourse) {
        this.courses.push(newCourse);
    };
    return CourseDataService2;
}());
exports.CourseDataService2 = CourseDataService2;
//# sourceMappingURL=course.service.js.map