﻿import {Http} from '@angular/http';
import {Injectable} from '@angular/core';

@Injectable() 
export class CourseDataService {
    courses: any[] = ['ReactJS', 'Angular2','NodeJS'];// get the data from server !

    constructor(private _http:Http) {
    }

    getRandomCourse() {
        return this.courses[Math.floor(Math.random() * this.courses.length)]
    }

    insertNewCourse(newCourse: string) {
        this.courses.push(newCourse);
    }
}

export class CourseDataService2 {
    courses: any[] = ['.NET', 'Java', 'PHP'];// get the data from server !

    getRandomCourse() {
        return this.courses[Math.floor(Math.random() * this.courses.length)]
    }

    insertNewCourse(newCourse: string) {
        this.courses.push(newCourse);
    }
}